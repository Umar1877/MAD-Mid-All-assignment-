# BMI Calculator with flutter
## Screenshots
<table style={border:"none"}><tr><td><img src="one.png" alt="Home Screen(default)"/></td><td><img src="two.png" alt="Home Screen(Location Popup)"/></td></tr></table>

### Other Apps
[Movie Rating app with flutter Bloc patten](https://github.com/imSanjaySoni/Movie-Rating-app-with-flutter-Bloc-patten) 

### Follow me.
 - <img src="https://image.flaticon.com/icons/svg/124/124011.svg" height="15" width="15" /> [Linkedin](https://linkedin.com/in/imsanjaysoni)
- <img src="https://image.flaticon.com/icons/svg/2111/2111463.svg" height="15" width="15" />  [Instagram ](https://instagram.com/imsanjaysoni)
- <img src="https://image.flaticon.com/icons/svg/124/124010.svg" height="15" width="15" /> [Facebook ](https://fb.com/imsanjaysoni)

